PASTOR ABBY'S FLOURISH 50TH - GIFT REGISTRY

FILES
- index.html : complete responsive registry page

IMPORTANT
This starter version uses browser localStorage, so reservations are only visible on the device/browser where they were made.
To make reservations sync live for everyone, host the page and connect the reservation functions to a small database such as Firebase Firestore or Supabase.

QUICK PUBLISH OPTIONS
1. GitHub Pages
   - Create a new repository
   - Upload index.html
   - Settings > Pages > Deploy from branch
   - Share the generated link

2. Netlify Drop
   - Go to Netlify Drop
   - Drag the folder/index.html into the page
   - Netlify gives you a public link

LIVE SHARED RESERVATIONS
For proper cross-device reservations, use Firebase Firestore or Supabase. Replace the localStorage save/read logic in index.html with database read/write calls.

PRIVACY SUGGESTION
Public page: show only AVAILABLE / RESERVED / GROUP GIFT.
Organiser view: show the reserver's name and note.
